function hide(element) {
    element.remove();
}

function turnOff(element) {
    element.innerText = "Log Out";
}

